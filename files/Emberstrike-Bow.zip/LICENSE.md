# Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)

This texture pack is licensed under the **CC BY-NC-SA 4.0** license.

## ✅ You are free to:
- **Use** this texture pack for personal or public gameplay.
- **Modify and share** it, as long as you credit **[Your Name]**.
- **Distribute** it under the **same** CC BY-NC-SA 4.0 license.

## ❌ You are NOT allowed to:
- **Sell, reupload, or distribute** this texture pack commercially.
- **Claim** this texture pack as your own.
- **Change the license** to remove restrictions.

## 🔗 More Details:
For full license information, visit: [Creative Commons License](https://creativecommons.org/licenses/by-nc-sa/4.0/)